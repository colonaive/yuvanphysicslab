globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/35087781016e896d.js",
    "static/chunks/f01a00b3eb970e1c.js",
    "static/chunks/73e02479bc7eeb6e.js",
    "static/chunks/2c2d9f43b137175b.js",
    "static/chunks/turbopack-4f47314ba368da62.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];