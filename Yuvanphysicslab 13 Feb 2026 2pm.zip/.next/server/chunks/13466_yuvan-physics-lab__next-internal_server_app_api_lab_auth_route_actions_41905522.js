module.exports=[86585,(e,o,d)=>{}];

//# sourceMappingURL=13466_yuvan-physics-lab__next-internal_server_app_api_lab_auth_route_actions_41905522.js.map