module.exports=[79144,(a,b,c)=>{}];

//# sourceMappingURL=13466_yuvan-physics-lab__next-internal_server_app__global-error_page_actions_c3769d31.js.map