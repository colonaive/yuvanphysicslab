module.exports=[8693,(a,b,c)=>{}];

//# sourceMappingURL=13466_yuvan-physics-lab__next-internal_server_app_%28lab%29_lab_page_actions_b7da0272.js.map