module.exports=[98466,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28public%29_research_page_actions_c978812b.js.map