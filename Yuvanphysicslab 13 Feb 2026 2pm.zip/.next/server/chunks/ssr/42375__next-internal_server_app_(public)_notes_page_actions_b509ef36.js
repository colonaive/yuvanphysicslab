module.exports=[80420,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28public%29_notes_page_actions_b509ef36.js.map