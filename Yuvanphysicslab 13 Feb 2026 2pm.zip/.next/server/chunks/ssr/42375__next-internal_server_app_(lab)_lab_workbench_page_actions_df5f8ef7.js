module.exports=[74494,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28lab%29_lab_workbench_page_actions_df5f8ef7.js.map