module.exports=[34244,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28lab%29_lab_latex_page_actions_b0a83f61.js.map