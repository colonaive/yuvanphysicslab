module.exports=[10370,(a,b,c)=>{}];

//# sourceMappingURL=13466_yuvan-physics-lab__next-internal_server_app__not-found_page_actions_4a9051bc.js.map