module.exports=[175,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28public%29_paper_page_actions_9afdbda9.js.map