module.exports=[5991,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28lab%29_lab_edit_%5Bid%5D_page_actions_fc667244.js.map