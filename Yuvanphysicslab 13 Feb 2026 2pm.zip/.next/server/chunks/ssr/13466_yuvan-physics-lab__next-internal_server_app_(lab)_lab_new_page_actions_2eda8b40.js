module.exports=[68405,(a,b,c)=>{}];

//# sourceMappingURL=13466_yuvan-physics-lab__next-internal_server_app_%28lab%29_lab_new_page_actions_2eda8b40.js.map