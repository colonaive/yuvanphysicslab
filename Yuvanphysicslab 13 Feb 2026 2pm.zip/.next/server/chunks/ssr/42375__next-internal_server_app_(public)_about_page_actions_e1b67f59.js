module.exports=[90153,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28public%29_about_page_actions_e1b67f59.js.map