module.exports=[37061,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28public%29_notes_%5Bslug%5D_page_actions_7a706719.js.map