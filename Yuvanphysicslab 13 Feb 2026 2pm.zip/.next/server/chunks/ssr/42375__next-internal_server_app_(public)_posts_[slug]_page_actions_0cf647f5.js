module.exports=[50311,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28public%29_posts_%5Bslug%5D_page_actions_0cf647f5.js.map