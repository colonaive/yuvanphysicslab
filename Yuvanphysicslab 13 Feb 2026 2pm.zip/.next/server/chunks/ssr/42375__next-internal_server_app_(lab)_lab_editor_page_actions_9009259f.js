module.exports=[61728,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28lab%29_lab_editor_page_actions_9009259f.js.map