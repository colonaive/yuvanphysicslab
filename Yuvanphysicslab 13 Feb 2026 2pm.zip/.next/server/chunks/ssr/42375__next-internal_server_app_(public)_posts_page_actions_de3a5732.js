module.exports=[7218,(a,b,c)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_%28public%29_posts_page_actions_de3a5732.js.map