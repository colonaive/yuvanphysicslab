module.exports=[52966,(e,o,d)=>{}];

//# sourceMappingURL=13466_yuvan-physics-lab__next-internal_server_app_robots_txt_route_actions_6cadaa3b.js.map