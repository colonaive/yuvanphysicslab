module.exports=[88808,(e,o,d)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_api_lab_session_route_actions_db8767de.js.map