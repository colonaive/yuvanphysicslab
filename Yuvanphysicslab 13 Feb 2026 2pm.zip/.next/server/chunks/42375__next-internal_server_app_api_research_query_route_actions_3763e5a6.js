module.exports=[48640,(e,o,d)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_api_research_query_route_actions_3763e5a6.js.map