module.exports=[22202,(e,o,d)=>{}];

//# sourceMappingURL=42375__next-internal_server_app_api_lab_logout_route_actions_87affd31.js.map