var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__41003316._.js")
R.c("server/chunks/[root-of-the-server]__9b30a441._.js")
R.c("server/chunks/13466_yuvan-physics-lab__next-internal_server_app_robots_txt_route_actions_6cadaa3b.js")
R.m(72698)
module.exports=R.m(72698).exports
