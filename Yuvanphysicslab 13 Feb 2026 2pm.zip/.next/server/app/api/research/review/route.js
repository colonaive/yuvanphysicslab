var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/research/review/route.js")
R.c("server/chunks/[root-of-the-server]__a7331b0f._.js")
R.c("server/chunks/[root-of-the-server]__9b30a441._.js")
R.c("server/chunks/OneDrive_yuvan-physics-lab_d0181ba7._.js")
R.c("server/chunks/42375__next-internal_server_app_api_research_review_route_actions_d2a533fc.js")
R.m(29795)
module.exports=R.m(29795).exports
