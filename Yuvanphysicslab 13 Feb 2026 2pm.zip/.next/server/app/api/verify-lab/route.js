var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/verify-lab/route.js")
R.c("server/chunks/[root-of-the-server]__85176d40._.js")
R.c("server/chunks/[root-of-the-server]__9b30a441._.js")
R.c("server/chunks/42375__next-internal_server_app_api_verify-lab_route_actions_7f07c595.js")
R.m(15412)
module.exports=R.m(15412).exports
