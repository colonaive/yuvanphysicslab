var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/lab/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0a82f7cf._.js")
R.c("server/chunks/[root-of-the-server]__9b30a441._.js")
R.c("server/chunks/42375__next-internal_server_app_api_lab_logout_route_actions_87affd31.js")
R.m(88333)
module.exports=R.m(88333).exports
