var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/lab/session/route.js")
R.c("server/chunks/[root-of-the-server]__93a8755f._.js")
R.c("server/chunks/[root-of-the-server]__9b30a441._.js")
R.c("server/chunks/OneDrive_yuvan-physics-lab_d0181ba7._.js")
R.c("server/chunks/42375__next-internal_server_app_api_lab_session_route_actions_db8767de.js")
R.m(3530)
module.exports=R.m(3530).exports
