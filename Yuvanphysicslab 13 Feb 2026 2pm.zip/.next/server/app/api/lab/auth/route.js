var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/lab/auth/route.js")
R.c("server/chunks/[root-of-the-server]__9c53f31f._.js")
R.c("server/chunks/[root-of-the-server]__9b30a441._.js")
R.c("server/chunks/13466_yuvan-physics-lab__next-internal_server_app_api_lab_auth_route_actions_41905522.js")
R.m(77032)
module.exports=R.m(77032).exports
