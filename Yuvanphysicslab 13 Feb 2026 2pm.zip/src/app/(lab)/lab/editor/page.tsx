import { redirect } from "next/navigation";

export default function LabEditorPage() {
  redirect("/lab/workbench");
}
