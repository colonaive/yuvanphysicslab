import { redirect } from "next/navigation";

export default function LabNewDraftPage() {
  redirect("/lab/editor");
}
