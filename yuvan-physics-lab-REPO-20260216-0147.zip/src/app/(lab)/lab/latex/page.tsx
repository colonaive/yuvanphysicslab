import { LatexScratchpad } from "@/components/lab/LatexScratchpad";

export default function ScratchpadPage() {
    return (
        <div className="h-full">
            <LatexScratchpad />
        </div>
    );
}
